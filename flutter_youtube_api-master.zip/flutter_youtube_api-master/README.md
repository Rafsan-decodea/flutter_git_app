# Flutter YouTube API and Video Player Tutorial | Apps From Scratch

[YouTube Tutorial](https://youtu.be/feQhHStBVLE)

Remember to add your own YouTube API Key to `utilities/keys.dart`.

`const String API_KEY = '<YOUR_API_KEY>';`
